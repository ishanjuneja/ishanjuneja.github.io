import { SidebarDirective } from './sidebar.directive';

describe('SidebarDirective', () => {
  it('should create an instance', () => {
    const directive = new SidebarDirective();
    expect(directive).toBeTruthy();
  });
});
