export type Config = {
  // selector?: String,
  multi?: boolean
};
