export type Menu = {
  name: string,
  iconClass: string,
  subIconClass?: string
  active: boolean,
  submenu: { name: string, url: string, subIconClass: string }[]
}
