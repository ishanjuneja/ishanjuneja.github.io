import { Component, OnInit, Input } from '@angular/core';
import { Config, Menu } from './types';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Input() options: Config = { multi: false };;

  @Input() menus: Menu[] = [
    {
      name: 'Home',
      iconClass: 'fa fa-home',
      active: false,
      submenu: [
        { name: 'HTML', url: '/home', subIconClass: 'fa fa-code' },
        { name: 'CSS', url: '/about', subIconClass: 'fa fa-code' },
        { name: 'Javascript', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Request',
      iconClass: 'fa fa-desktop',
      active: false,
      submenu: [
        { name: 'Tablets', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Mobiles', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Platform',
      iconClass: 'fa fa-globe',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Business Unit',
      iconClass: 'fa fa-suitcase',
      active: false,
      submenu: [
        { name: 'Create New', url: '#', subIconClass: 'fa fa-plus' },
        { name: 'Update', url: '#', subIconClass: 'fa fa-file-invoice-dollar' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' },
        { name: 'Active/Inactive', url: '#', subIconClass: 'fa fa-bolt' }
      ]
    },
    {
      name: 'Trading Partner',
      iconClass: 'fa fa-user-friends',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Endpoints and Gateways',
      iconClass: 'fa fa-window-maximize',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Reports',
      iconClass: 'fa fa-file-contract',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Users',
      iconClass: 'fa fa-users',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Utility',
      iconClass: 'fa fa-chart-bar',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    },
    {
      name: 'Admin',
      iconClass: 'fa fa-user',
      active: false,
      submenu: [
        { name: 'Chrome', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Firefox', url: '#', subIconClass: 'fa fa-code' },
        { name: 'Desktop', url: '#', subIconClass: 'fa fa-code' }
      ]
    }
  ];
  config: Config={};

  ngOnInit() {
    this.config = this.mergeConfig(this.options);
  }

  mergeConfig(options: Config) {
    const config = {
      // selector: '#app-navbar',
      multi: true
    };

    return { ...config, ...options };
  }

  toggle(index: number) {
    // submenu
    if (!this.config.multi) {
      this.menus.filter(
        (menu, i) => i !== index && menu.active
      ).forEach(menu => menu.active = !menu.active);
    }

    // Menu active
    this.menus[index].active = !this.menus[index].active;
  }
}
