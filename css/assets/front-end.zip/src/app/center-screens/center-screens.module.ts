import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CenterScreensRoutingModule } from './center-screens-routing.module';
import { CenterScreensComponent } from './center-screens.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { NgbCarouselModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    CenterScreensComponent,
    HomeComponent,
    AboutComponent
  ],
  imports: [
    CommonModule,
    CenterScreensRoutingModule,
    NgbModule
  ]
})
export class CenterScreensModule { }
