import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-center-screens',
  templateUrl: './center-screens.component.html',
  styleUrls: ['./center-screens.component.css']
})
export class CenterScreensComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
